export * from './src/app/modules/resume/resume.module'
