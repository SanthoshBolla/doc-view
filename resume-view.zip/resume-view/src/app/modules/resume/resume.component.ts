import { Component, OnInit, Input, Pipe, PipeTransform } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-resume-view',
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.scss'],
})

export class ResumeComponent implements OnInit {
  showSpinner: boolean;
  showIframe: boolean;
  showLoadingMsg: boolean;
  resumeDocUrl: SafeResourceUrl;;
  htmlString = '';
  showHodResume: boolean;
  @Input('data') resumeData: any;
  resumeHODPrefix = 'https://api.havenondemand.com/1/api/sync/viewdocument/v1?url=';
  resumeHODSuffix = '&apikey=8fb08e0c-9ecb-49ee-ab72-a600eff9931b';
  resumeGooglePrefix = 'https://docs.google.com/viewer?url=';
  resumeGoogleSuffix = '&embedded=true';
  private headers = new Headers({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  });
  private options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http,private sanitizer: DomSanitizer) {

   }

  ngOnInit() {
    this.showSpinner = true;
    console.log(this.resumeData);
    this.checkHODStatus(this.resumeData.resumeDocLink);
    this.checkHtmlStringFromS3(this.resumeData.resumeHtmlLink);
  }
  checkHODStatus(url): void {
    const that = this;
    this.http.get(this.resumeHODPrefix+url+this.resumeHODSuffix).subscribe(res => {
      if (res.status == 200 && !this.htmlString) {
        this.showHodResume = true;
        this.resumeDocUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.resumeHODPrefix+url+this.resumeHODSuffix);
        console.log('HOD is up..');
      } else if(!this.htmlString){
        console.log('HOD is down.Displaying resume using ');
        this.showHodResume = false;
        // Display resume using google doc viewer
        this.resumeDocUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.resumeGooglePrefix+url+this.resumeGoogleSuffix);
      }
      if(!this.htmlString){
        setTimeout(() => {
          that.showIframe = true;
          that.showSpinner = false;
          that.showLoadingMsg = true;
        }, 3000);
      }
    }, e => {
        console.error("Error in checking hod status", e);
        // Display resume using google doc viewer
        if(!this.htmlString){
          this.resumeDocUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.resumeGooglePrefix+url+this.resumeGoogleSuffix);
          setTimeout(() => {
            that.showIframe = true;
            that.showSpinner = false;
            that.showLoadingMsg = true;
          }, 3000);
        }
    })
  }
  checkHtmlStringFromS3(url): void {
    const that = this;
    this.showSpinner = false;
    this.http.get(url).subscribe(res => {
      console.log(res);
      if (res.status == 200) {
        console.log('Html resume available..');
        this.htmlString = res['_body'];
        this.showHodResume = false;
        this.showSpinner = false;
        this.resumeDocUrl = '';
      } else {
        console.log('Html resume not available');
        this.htmlString = '';
      }
    }, err => {
      console.error("Error in getting resume html string",err);
      this.htmlString = '';
    });
    setTimeout(() => {
      if(!that.htmlString){
        this.showSpinner = true;
      }
    }, 1000);
  }
}
